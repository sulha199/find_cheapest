import React from 'react';
import 'whatwg-fetch';
//import IssueAdd from './IssueAdd.jsx';
//import IssueFilter from './IssueFilter.jsx';

const CollectionItem = (props) => (
            <li>
            <item>
                <div className="product">
                    <div className="product-image">
                        <img src={props.item.img}/>
                    </div>
                    <div className="product-title">
                        <span>{props.item.title}</span>
                    </div>
                    <div className="products-info">
                        <div className="product-seller">
                            <span>{props.item.seller_name}</span>
                        </div>
                        <div className="product-location">
                            <span>{props.item.location}</span>
                        </div>
                        <div className="product-price">
                            <span>{props.item.price}</span>
                        </div>
                        <div className="product-condition">
                            <span>{props.item.condition}</span>
                        </div>
                    </div>
                </div>
            </item>
            </li>
            )

function ItemsDisplay(props) {
    const items = props.items.map(item => <CollectionItem key={item._id} item={item} />)
    return (
            <ul>{items}</ul>
            );
}

export default class Collection extends React.Component {
    constructor() {
        super();
        this.state = {items: []};
        //this.createIssue = this.createIssue.bind(this);
    }
    componentDidMount() {
        this.loadBl();
    }
    loadBl() {
        fetch('https://api.bukalapak.com/v2/products.json?keywords=fixie&page=1&per_page=20').then(response => {
            if (response.ok) {
                response.json().then(data => {
                    console.log("Total count of records:", data.products.length);
                    var temp = [];
                    data.products.forEach(item => {
                        temp.push({
                            title: item.name,
                            img: item.small_images[0],
                            seller_name: item.seller_name,
                            location: item.city,
                            price: item.price,
                            condition : item.condition,
                        });
                    });
                    this.setState({items: temp});
                });
            } else {
                response.json().then(error => {
                    alert("Failed to fetch issues:" + error.message)
                });
            }
        }).catch(err => {
            alert("Error in fetching data from server:", err);
        });
    }
       
    render() {
        return (
                <div>
                    <h1>List</h1>
                    
                    <hr />
                    <ItemsDisplay items={this.state.items} />                
                    <hr />                    
                </div>
                );
    }
}