import React from 'react';

export default class IssueFilter extends React.Component {
    render() {
        return (
                <div>This is a placeholder for the Issue Filter.</div>
                )
    }
}